gcc -o dcraw -O4 dcraw.c -lm -NODEPS
