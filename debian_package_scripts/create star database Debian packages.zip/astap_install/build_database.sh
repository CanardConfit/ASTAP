cd ~/astap_install
#sudo fakeroot dpkg-deb --build ~/astap_install/w08_star_database_mag08_astap
#sudo fakeroot dpkg-deb --build ~/astap_install/v16_star_database_mag16_colour_hnsky
#sudo fakeroot dpkg-deb --build ~/astap_install/g17_star_database_mag17_astap
#sudo fakeroot dpkg-deb --build ~/astap_install/v17_star_database_mag17_colour_astap
#sudo fakeroot dpkg-deb --build ~/astap_install/g17_star_database_mag17_hnsky
#sudo fakeroot dpkg-deb --build ~/astap_install/v17_star_database_mag17_colour_hnsky
#sudo fakeroot dpkg-deb --build ~/astap_install/g18_star_database_mag18_hnsky
#sudo fakeroot dpkg-deb --build ~/astap_install/d05_star_database
#sudo fakeroot dpkg-deb --build ~/astap_install/d20_star_database
#sudo fakeroot dpkg-deb --build ~/astap_install/d50_star_database

#sudo fakeroot dpkg-deb --build ~/astap_install/g05_star_database
sudo fakeroot dpkg-deb --build ~/astap_install/v50_star_database



